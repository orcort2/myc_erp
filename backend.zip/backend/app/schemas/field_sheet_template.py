from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field


FieldSheetBlockType = Literal[
    "HeaderBlock",
    "ClientBlock",
    "ServiceOrderBlock",
    "EquipmentBlock",
    "CalibrationDataBlock",
    "EnvironmentalBlock",
    "StandardsBlock",
    "ResultsTableBlock",
    "ObservationsBlock",
    "SignaturesBlock",
    "FooterBlock",
    "CustomFieldsBlock",
    "SectionBlock",
    "AttachmentPlaceholderBlock",
    "GeneralDataBlock",
    "EquipmentDataBlock",
    "SimpleComparisonTableBlock",
    "MultiPointTableBlock",
    "SectionedTableBlock",
    "RepeatabilityTableBlock",
    "DimensionalTableBlock",
    "PressureTableBlock",
    "MassBalanceTableBlock",
    "ElectricalTableBlock",
]


class ResultColumnRead(BaseModel):
    key: str
    label: str
    source: str | None = None
    width: str | None = None
    unit: str | None = None
    editable: bool = True
    required: bool = False
    data_type: str = "text"
    suggested_unit: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="allow")


class ResultSectionRead(BaseModel):
    key: str
    title: str
    rows: int
    columns: list[ResultColumnRead]
    allow_add_rows: bool | None = None
    allow_remove_rows: bool | None = None
    min_rows: int | None = None
    max_rows: int | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="allow")


class FieldSheetFieldRead(BaseModel):
    key: str
    label: str
    field_type: str = "text"
    required: bool = False
    visible: bool = True
    order: int = 0
    placeholder: str | None = None
    help_text: str | None = None
    options: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="allow")


class FieldSheetTemplateBlockRead(BaseModel):
    key: str
    block_key: str | None = None
    block_type: FieldSheetBlockType
    title: str
    order: int | None = None
    visible: bool = True
    visible_fields: list[str] = Field(default_factory=list)
    fields: list[FieldSheetFieldRead] = Field(default_factory=list)
    columns: list[ResultColumnRead] = Field(default_factory=list)
    sections: list[ResultSectionRead] = Field(default_factory=list)
    table_config: dict[str, Any] = Field(default_factory=dict)
    suggested_unit: str | None = None
    rows: int | None = None
    min_rows: int | None = None
    max_rows: int | None = None
    allow_add_rows: bool = False
    allow_remove_rows: bool = False
    required: bool = False
    print_order: int = 0
    capture_order: int = 0
    print_visible: bool = True
    capture_visible: bool = True
    pdf_visible: bool = True
    metadata: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="allow")


class FieldSheetTemplateCreate(BaseModel):
    template_key: str = Field(min_length=1, max_length=60)
    name: str = Field(min_length=1, max_length=180)
    description: str | None = None
    status: str = Field(default="draft", max_length=40)
    code: str = Field(default="FCA-30", max_length=40)
    revision: str = Field(default="R1", max_length=40)
    pages: int = Field(default=1, ge=1)
    pdf_template: str = Field(default="field_sheet_general_pdf.html", max_length=120)
    document_code: str | None = Field(default=None, max_length=80)
    document_revision: str | None = Field(default=None, max_length=80)
    table_family: str | None = Field(default=None, max_length=80)
    blocks: list[FieldSheetTemplateBlockRead] = Field(default_factory=list)
    result_sections: list[ResultSectionRead] = Field(default_factory=list)
    visible_fields: list[str] = Field(default_factory=list)
    validations: dict[str, Any] = Field(default_factory=dict)
    print_config: dict[str, Any] = Field(default_factory=dict)
    pdf_config: dict[str, Any] = Field(default_factory=dict)
    permissions_config: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    signature_layout: dict[str, Any] = Field(default_factory=dict)
    pagination: dict[str, Any] = Field(default_factory=dict)
    automation: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="allow")


class FieldSheetTemplateUpdate(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=180)
    description: str | None = None
    status: str | None = Field(default=None, max_length=40)
    code: str | None = Field(default=None, max_length=40)
    revision: str | None = Field(default=None, max_length=40)
    pages: int | None = Field(default=None, ge=1)
    pdf_template: str | None = Field(default=None, max_length=120)
    document_code: str | None = Field(default=None, max_length=80)
    document_revision: str | None = Field(default=None, max_length=80)
    table_family: str | None = Field(default=None, max_length=80)
    blocks: list[FieldSheetTemplateBlockRead] | None = None
    result_sections: list[ResultSectionRead] | None = None
    visible_fields: list[str] | None = None
    validations: dict[str, Any] | None = None
    print_config: dict[str, Any] | None = None
    pdf_config: dict[str, Any] | None = None
    permissions_config: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None
    signature_layout: dict[str, Any] | None = None
    pagination: dict[str, Any] | None = None
    automation: dict[str, Any] | None = None

    model_config = ConfigDict(extra="allow")


class FieldSheetTemplateImport(BaseModel):
    template: FieldSheetTemplateCreate
    activate: bool = False
    mode: Literal["new_version", "new_key"] = "new_version"
    new_template_key: str | None = Field(default=None, max_length=60)


class FieldSheetTemplateCatalogRead(BaseModel):
    block_types: list[dict[str, Any]]
    table_families: list[dict[str, Any]]
    supported_template_keys: list[str]


class FieldSheetTemplateRead(BaseModel):
    id: int | None = None
    source: Literal["database", "fallback"] = "fallback"
    template_key: str
    key: str
    name: str
    description: str | None = None
    type: str
    status: str
    version: int
    is_active: bool = True
    code: str
    revision: str
    pages: int
    pdf_template: str
    document_code: str | None = None
    document_revision: str | None = None
    table_family: str | None = None
    visible_fields: list[str]
    result_sections: list[ResultSectionRead]
    blocks: list[FieldSheetTemplateBlockRead]
    validations: dict[str, Any] = Field(default_factory=dict)
    print_config: dict[str, Any] = Field(default_factory=dict)
    pdf_config: dict[str, Any] = Field(default_factory=dict)
    permissions_config: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    signature_layout: dict[str, Any] = Field(default_factory=dict)
    pagination: dict[str, Any] = Field(default_factory=dict)
    automation: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(extra="allow")
