"""Core services and configuration."""

